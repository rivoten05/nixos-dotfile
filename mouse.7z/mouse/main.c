#include <windows.h>

int main(){
    POINT p;

    while(1){
        Sleep(120000);
        GetCursorPos(&p);
        SetCursorPos(p.x + 1, p.y);

    }

    return 0; 
}